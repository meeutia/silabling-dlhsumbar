// components/auth/AuthLogoPanel.jsx
import logoUptd from '../../assets/logo-uptd.png';
import logoSumbar from '../../assets/logo-sumbar.png';
import logoKan from '../../assets/kan-logo.png';

export function AuthLogoPanel() {
  return (
    <div className="relative flex flex-col overflow-hidden min-h-[340px] lg:min-h-full bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 p-8 lg:p-12">
      
      {/* Background pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, white 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Decorative gradient orbs */}
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-white/[0.03] rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-80 h-80 bg-white/[0.02] rounded-full blur-3xl pointer-events-none" />

      {/* Top accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

      {/* ── Header institusi ── */}
      <div className="relative z-10 mb-8">
        <div className="inline-flex items-center gap-2 mb-3">
          <div className="w-1 h-6 bg-gradient-to-b from-emerald-300 to-teal-400 rounded-full" />
          <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-emerald-200 opacity-80">
            Dikelola oleh
          </p>
        </div>
        <h3 className="text-2xl lg:text-3xl font-bold text-white leading-tight">
          UPTD Laboratorium<br />
          <span className="text-emerald-200">Lingkungan Hidup</span>
        </h3>
        <p className="text-xs text-white/50 mt-2">Pemerintah Provinsi Sumatera Barat</p>
      </div>

      {/* ── Main content area ── */}
      <div className="relative z-10 flex flex-col gap-6 flex-1">

        {/* Logo grid - 2x1 */}
        <div className="grid grid-cols-2 gap-3.5">
          {/* Logo UPTD */}
          <div className="group relative flex items-center justify-center rounded-2xl bg-gradient-to-br from-white to-white/90 p-5 min-h-[110px] shadow-lg hover:shadow-xl transition-all duration-300 border border-white/50">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/5 group-hover:to-emerald-500/10 transition-all" />
            <img 
              src={logoUptd} 
              alt="Logo UPTD Laboratorium Lingkungan" 
              className="max-h-16 w-full object-contain relative z-10"
            />
          </div>

          {/* Logo Sumbar */}
          <div className="group relative flex items-center justify-center rounded-2xl bg-gradient-to-br from-white to-white/90 p-5 min-h-[110px] shadow-lg hover:shadow-xl transition-all duration-300 border border-white/50">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/5 group-hover:to-emerald-500/10 transition-all" />
            <img 
              src={logoSumbar} 
              alt="Logo Pemerintah Provinsi Sumatera Barat" 
              className="max-h-16 w-full object-contain relative z-10"
            />
          </div>
        </div>

        {/* Certification section divider */}
        <div className="flex items-center gap-3 my-2">
          <div className="flex-1 h-px bg-gradient-to-r from-white/10 via-white/20 to-white/10" />
          <div className="flex items-center gap-1.5">
            <svg className="w-4 h-4 text-emerald-300" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 15a5 5 0 100-10 5 5 0 000 10zm0 2a7 7 0 100-14 7 7 0 000 14zm1-7a1 1 0 11-2 0 1 1 0 012 0z" />
            </svg>
            <span className="text-[9px] tracking-widest uppercase font-semibold text-emerald-200">Terakreditasi</span>
            <svg className="w-4 h-4 text-emerald-300" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 15a5 5 0 100-10 5 5 0 000 10zm0 2a7 7 0 100-14 7 7 0 000 14zm1-7a1 1 0 11-2 0 1 1 0 012 0z" />
            </svg>
          </div>
          <div className="flex-1 h-px bg-gradient-to-r from-white/10 via-white/20 to-white/10" />
        </div>

        {/* KAN Accreditation logo */}
        <div className="group relative flex items-center justify-center rounded-2xl bg-gradient-to-br from-white to-white/90 p-6 min-h-[96px] shadow-lg hover:shadow-xl transition-all duration-300 border border-white/50">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/5 group-hover:to-emerald-500/10 transition-all" />
          <img
            src={logoKan}
            alt="Logo Komite Akreditasi Nasional"
            className="max-h-14 max-w-[240px] w-full object-contain relative z-10"
          />
        </div>
      </div>

      {/* ── Footer security badge ── */}
      <div className="relative z-10 mt-8 pt-6 border-t border-white/10">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 mt-1">
            <svg className="w-4 h-4 text-emerald-300" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.293 9.293a1 1 0 011.414 0L10 12.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </div>
          <p className="text-xs text-white/60 leading-relaxed">
            Sistem ini beroperasi sesuai standar keamanan data pemerintah. Semua komunikasi terenkripsi dan terlindungi.
          </p>
        </div>
      </div>

      {/* Bottom accent line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent pointer-events-none" />
    </div>
  );
}