import { requestBlob, requestData, requestJson } from './httpClient';

export const customerRequestApi = {
  getHolidays() {
    return requestData('/references/holidays', {}, { auth: true });
  },

  getAdminContact() {
    return requestData('/references/admin-contact', {}, { auth: true });
  },

  getRequests() {
    return requestData('/requests', {}, { auth: true });
  },

  getDetail(registrationNumber) {
    return requestData(`/requests/${registrationNumber}`, {}, { auth: true });
  },

  submitPaymentDecision(registrationNumber, payload) {
    return requestJson(
      `/requests/${registrationNumber}/payment`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
      { auth: true }
    );
  },

  confirmPayment(registrationNumber, formData) {
    return requestJson(
      `/requests/${registrationNumber}/payment/confirm`,
      {
        method: 'POST',
        body: formData,
      },
      { auth: true }
    );
  },

  getInvoicePdfBlob(registrationNumber) {
    return requestBlob(
      `/requests/${registrationNumber}/invoice/pdf`,
      {},
      { auth: true }
    );
  },

  confirmSchedule(registrationNumber, payload) {
    return requestJson(
      `/requests/${registrationNumber}/schedule-confirmation`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      },
      { auth: true }
    );
  },

  requestScheduleChange(payload) {
    return requestJson(
      '/requests/schedule-changes',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      },
      { auth: true }
    );
  },

  cancelScheduleChange(idPengajuan) {
    return requestJson(
      `/requests/schedule-changes/${idPengajuan}/cancel`,
      { method: 'POST' },
      { auth: true }
    );
  },

};
